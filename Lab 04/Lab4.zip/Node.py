class Node:
    def __init__(self,state,parent,actions,total_cost) :
        self.state=state
        self.parent=parent
        self.actions=actions
        self.totalCost=total_cost
        